/*
 * Decompiled with CFR 0.152.
 */
package com.schnurritv.sexmod.proxy;

import com.schnurritv.sexmod.proxy.CommonProxy;

public class ClientProxy
extends CommonProxy {
}

