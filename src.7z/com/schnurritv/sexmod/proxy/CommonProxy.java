/*
 * Decompiled with CFR 0.152.
 */
package com.schnurritv.sexmod.proxy;

public class CommonProxy {
}

