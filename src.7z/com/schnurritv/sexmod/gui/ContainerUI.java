/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.inventory.Container
 */
package com.schnurritv.sexmod.gui;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;

public class ContainerUI
extends Container {
    public boolean func_75145_c(EntityPlayer playerIn) {
        return true;
    }
}

