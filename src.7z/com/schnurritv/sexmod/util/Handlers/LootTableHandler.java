/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.ResourceLocation
 *  net.minecraft.world.storage.loot.LootTableList
 */
package com.schnurritv.sexmod.util.Handlers;

import net.minecraft.util.ResourceLocation;
import net.minecraft.world.storage.loot.LootTableList;

public class LootTableHandler {
    public static final ResourceLocation GIRL = LootTableList.func_186375_a((ResourceLocation)new ResourceLocation("sexmod", "girl"));
}

